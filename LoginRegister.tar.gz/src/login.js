import React from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
// import Link from "@mui/material/Link";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import svgfile from './backsvg.svg';
import {useSelector,useDispatch} from 'react-redux';
import {Link} from 'react-router-dom';
import Divider from '@mui/material/Divider';
import google from './google.png';
import facebook from './facebook.png';
// import backimage from "../assets/backvimage.jpg";
// import signimage from "../assets/virtualReality.png";
// import sideimage from "../assets/loginsideimage.png";



function Login() {
  const show = useSelector(state=>state.show)
  const dispatch = useDispatch()
  return (
    <Grid container sx={{
      height:"100vh"
    }}>
      <CssBaseline />
      <Grid
        item
        xs={false}
        sm={4}
        md={6}
        sx={{
          backgroundImage: "url(https://source.unsplash.com/random)",
          backgroundRepeat: "no-repeat",
          backgroundColor: (t) =>
            t.palette.mode === "light"
              ? t.palette.grey[50]
              : t.palette.grey[900],
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <Grid item xs={12} sm={8} md={6} component={Paper} elevation={6} square style={{
      backgroundImage: `url(${svgfile})`,
      backgroundPosition:'center',
      backgroundRepeat:'no-repeat',
      backgroundSize:'cover',
    }}>
        {

          show ?
          <Box
            sx={{
              my: {sm:13,xs:13},
              mx: {sm:12,xs:6},
              paddingTop:5,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            {/* <Avatar sx={{ m: 1, bgcolor: "light.main" }}> */}
            {/*   <img src={signimage} alt="icons_are" /> */}
            {/* </Avatar> */}
            <Typography component="h1" variant="h5" sx={{fontWeight:900}}>
              Sign In
            </Typography>
            <Box
              component="form"
              noValidate
              // onSubmit={handleSubmit}
              sx={{ mt: 1 }}
            >
              <TextField
                margin="normal"
                required
                fullWidth
                id="email"
                label="Email Address"
                name="email"
                autoComplete="email"
                autoFocus
                sx={{boxShadow:3}}
              />
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
                autoComplete="current-password"
                sx={{boxShadow:3}}
              />
              <FormControlLabel
                control={<Checkbox value="remember" color="primary" />}
                label="Remember me"
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 2, mb: 2 ,boxShadow:3,fontWeight:900}}
              >
                Sign in
              </Button>
              <Grid container>
                <Grid item>
                  <Link to="/register" onClick={()=>dispatch({type:'register'})}>
                    Don't have an account? Sign Up
                  </Link>
                </Grid>
              </Grid>
              <div className="d-flex justify-content-center mt-4">
              <h5 style={{fontWeight:900}}><Divider/>OR<Divider/></h5>
              </div>
              <div className="d-flex justify-content-center mt-1">
                <img src={google} alt='google' height="50" className="m-3"/>
                <img src={facebook} alt='facebook' height="50" className="m-3"/>
              </div>
              </Box>
          </Box>

           :

           <Box
            sx={{
              my: {sm:13,xs:13},
              mx: {sm:12,xs:6},
              paddingTop:5,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}
          >
            <Typography component="h1" variant="h5" sx={{fontWeight:900}}>
            Sign Up
            </Typography>
            <Typography variant="h6" component="h6" sx={{fontWeight:100,fontSize:'90%',marginTop:1}}>
            <Divider/>
             Welcome to Event Render
             <Divider/>
            </Typography>
            <Box component="form" noValidate sx={{ mt: 3 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    autoComplete="given-name"
                    name="firstName"
                    required
                    fullWidth
                    id="firstName"
                    label="First Name"
                    autoFocus
                    sx={{boxShadow:3}}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    id="lastName"
                    label="Last Name"
                    name="lastName"
                    autoComplete="family-name"
                    sx={{boxShadow:3}}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="email"
                    label="Email Address"
                    name="email"
                    autoComplete="email"
                    sx={{boxShadow:3}}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    name="password"
                    label="Password"
                    type="password"
                    id="password"
                    autoComplete="new-password"
                    sx={{boxShadow:3}}
                  />
                </Grid>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={<Checkbox value="allowExtraEmails" color="primary" />}
                    label="Agree on terms and conditions"
                  />
                </Grid>
              </Grid>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 5 }}
                sx={{boxShadow:3,fontWeight:900}}
              >
                Sign Up
              </Button>
              <Grid container justifyContent="flex-end" sx={{marginTop:2}}>
                <Grid item>
                  <Link to="/login" onClick={()=>dispatch({type:'login'})}>
                    Already have an account? Sign in
                  </Link>
                </Grid>
              </Grid>
            </Box>
          </Box>
        }
        
      </Grid>
    </Grid>
  );
}

export default Login;
