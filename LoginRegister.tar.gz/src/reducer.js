let initialvalue = {
	show:true
}

export const reducer = (state = initialvalue,action)=>{

if(action.type === 'login'){
return {show:true}
}
if(action.type === 'register'){
return {show:false}
}
return state
}