import React from 'react';
import {useDispatch} from 'react-redux';
import {Link} from 'react-router-dom';

function Home (){
	const dispatch = useDispatch()
	return (
		<>
		<div className="d-flex flex-column">
		<div>Home</div>
		<Link to="/login" onClick={()=>dispatch({type:'login'})}>Login</Link>
		<Link to="/register" onClick={()=>dispatch({type:'register'})}>Register</Link>
		</div>
		</>
		)
}

export default Home;