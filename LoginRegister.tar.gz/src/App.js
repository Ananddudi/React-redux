import React from 'react';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import Login from './login';
import Home from  './Home';
import {useSelector} from 'react-redux';

function App() {
  const show = useSelector((state)=>state.show)
  return (
    <Router>
      <Switch>
        <Route exact path={show ? '/login':'/register'} component={Login}/>
        <Route path="/dashboard" component={Home}/>
      </Switch>
    </Router>
  );
}

export default App;
